import React from 'react';

import ComputationScreen from './ComputationScreen/ComputationScreen';
import ResultScreen from './ResultScreen/ResultScreen';

const screen = (props) => (
    <section className="screen">
        <ComputationScreen>{props.equation}</ComputationScreen>
		<ResultScreen>{props.result}</ResultScreen>
    </section>
);

export default screen;