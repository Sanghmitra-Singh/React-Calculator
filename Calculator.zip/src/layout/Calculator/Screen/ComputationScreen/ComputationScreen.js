import React from 'react';

const computationScreen = (props) => (
    <div className="computation-screen">
        {props.children}
    </div>
);

export default computationScreen;