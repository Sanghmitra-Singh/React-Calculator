import React from 'react';

import KeypadRow from './KeypadRow/KeypadRow';
import Button from '../../../components/Button/Button';
import LargeButton from '../../../components/Button/LargeButton/LargeButton';

const keypad = props => (
    <section className="keypad">
        {/* row #1 */}
        <KeypadRow>
            <Button type="primary" class="row-3 col-1" onButtonPress={props.onButtonPress}>C</Button>
            <Button type="primary" class="row-3 col-2" onButtonPress={props.onButtonPress}>+/-</Button>
            <Button type="primary" class="row-3 col-3" onButtonPress={props.onButtonPress}>%</Button>
            <Button type="operator" class="row-3 col-4" onButtonPress={props.onButtonPress}>÷</Button>
        </KeypadRow>

        {/* row #2 */}
        <KeypadRow>
            <Button type="number" class="row-4 col-1" onButtonPress={props.onButtonPress}>7</Button>
            <Button type="number" class="row-4 col-2" onButtonPress={props.onButtonPress}>8</Button>
            <Button type="number" class="row-4 col-3" onButtonPress={props.onButtonPress}>9</Button>
            <Button type="operator" class="row-4 col-4" onButtonPress={props.onButtonPress}>*</Button>
        </KeypadRow>

        {/* row #3 */}
        <KeypadRow>
            <Button type="number" class="row-5 col-1" onButtonPress={props.onButtonPress}>4</Button>
            <Button type="number" class="row-5 col-2" onButtonPress={props.onButtonPress}>5</Button>
            <Button type="number" class="row-5 col-3" onButtonPress={props.onButtonPress}>6</Button>
            <Button type="operator" class="row-5 col-4" onButtonPress={props.onButtonPress}>-</Button>
        </KeypadRow>

        {/* row #4 */}
        <KeypadRow>
            <Button type="number" class="row-6 col-1" onButtonPress={props.onButtonPress}>1</Button>
            <Button type="number" class="row-6 col-2" onButtonPress={props.onButtonPress}>2</Button>
            <Button type="number" class="row-6 col-3" onButtonPress={props.onButtonPress}>3</Button>
            <Button type="operator" class="row-6 col-4" onButtonPress={props.onButtonPress}>+</Button>
        </KeypadRow>

        {/* row #5 */}
        <KeypadRow>
            <Button type="number" class="row-7 col-1" onButtonPress={props.onButtonPress}>0</Button>
			<Button type="number" class="row-7 col-2" onButtonPress={props.onButtonPress}></Button>
            <Button type="number" class="row-7 col-3" onButtonPress={props.onButtonPress}>.</Button>
			<LargeButton class="row-7 col-4" onButtonPress={props.onButtonPress}>=</LargeButton>
        </KeypadRow>
    </section>
);

export default keypad;